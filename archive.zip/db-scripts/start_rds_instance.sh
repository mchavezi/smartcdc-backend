#!/bin/bash

# Database credentials
DB_HOST="cdcdemo7-postgres.cmuczqmmtr0o.us-east-1.rds.amazonaws.com"
DB_PORT="5432"
DB_NAME="cdcdemo7_db"
DB_USER="cdcdemo7_admin"
DB_PASSWORD="GC5gA7P=1}1p"

# AWS Region
AWS_REGION="us-east-1"

# RDS Instance Identifier
RDS_IDENTIFIER="cdcdemo7-postgres"  # Replace with your actual RDS instance identifier

# Function to start the RDS instance
start_rds_instance() {
  echo "Starting RDS instance: $RDS_IDENTIFIER in region $AWS_REGION..."
  aws rds start-db-instance --db-instance-identifier "$RDS_IDENTIFIER" --region "$AWS_REGION"
  
  if [ $? -eq 0 ]; then
    echo "Successfully initiated starting of RDS instance: $RDS_IDENTIFIER"
  else
    echo "Failed to start RDS instance: $RDS_IDENTIFIER"
  fi
}

# Main script execution
start_rds_instance
