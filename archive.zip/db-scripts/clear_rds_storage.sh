#!/bin/bash

# Database credentials
DB_HOST="cdcdemo7-postgres.cmuczqmmtr0o.us-east-1.rds.amazonaws.com"
DB_PORT="5432"
DB_NAME="cdcdemo7_db"
DB_USER="cdcdemo7_admin"
DB_PASSWORD="GC5gA7P=1}1p"

# AWS Region
AWS_REGION="us-east-1"

# RDS Instance Identifier
RDS_IDENTIFIER="cdcdemo7-postgres"  # Replace with your actual RDS instance identifier

# Function to start the RDS instance
start_rds_instance() {
  echo "Starting RDS instance: $RDS_IDENTIFIER in region $AWS_REGION..."
  aws rds start-db-instance --db-instance-identifier "$RDS_IDENTIFIER" --region "$AWS_REGION"
  
  if [ $? -eq 0 ]; then
    echo "Successfully initiated starting of RDS instance: $RDS_IDENTIFIER"
  else
    echo "Failed to start RDS instance: $RDS_IDENTIFIER"
  fi
}

# Function to clear database storage by removing logs, vacuuming and clearing old data
clear_storage() {
  echo "Connecting to PostgreSQL database to clear storage..."

  PGPASSWORD=$DB_PASSWORD psql -h $DB_HOST -p $DB_PORT -U $DB_USER -d $DB_NAME -c "VACUUM FULL;"

  if [ $? -eq 0 ]; then
    echo "Successfully ran VACUUM FULL to reclaim space."
  else
    echo "Failed to run VACUUM FULL."
  fi

  # Optionally, delete old logs (adjust as necessary)
  echo "Deleting old logs..."
  PGPASSWORD=$DB_PASSWORD psql -h $DB_HOST -p $DB_PORT -U $DB_USER -d $DB_NAME -c "DELETE FROM pg_stat_activity WHERE state = 'idle' AND state_change < NOW() - INTERVAL '7 days';"

  if [ $? -eq 0 ]; then
    echo "Successfully cleared old logs."
  else
    echo "Failed to clear old logs."
  fi

  # Optional: Adjust autovacuum settings if necessary (to help prevent future storage issues)
  echo "Checking autovacuum settings..."
  PGPASSWORD=$DB_PASSWORD psql -h $DB_HOST -p $DB_PORT -U $DB_USER -d $DB_NAME -c "SHOW autovacuum;"

  # Add other cleanup commands as needed (e.g., clearing old partitions, truncating large tables)
}

# Main script execution
start_rds_instance
clear_storage
