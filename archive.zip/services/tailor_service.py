# backend/services/tailor_service.py
from openai import OpenAI
from docx import Document
from dotenv import load_dotenv
import os
import tiktoken
from typing import List, Dict
from docx.shared import Pt, RGBColor, Inches
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.text import WD_LINE_SPACING
from docx.enum.style import WD_STYLE_TYPE
from docx.shared import Inches, Pt, RGBColor


load_dotenv()

# Initialize the OpenAI client
client = OpenAI(
    api_key=os.getenv('OPENAI_API_KEY'),
    organization=os.getenv('OPENAI_ORG_ID'),
    project=os.getenv('OPENAI_PROJECT_ID'),
)



def customize_resume(resume_text, job_description):
    # """
    # Uses OpenAI's GPT-4 model to tailor a resume based on a job description.
    # """
     prompt = f"""
You are an expert resume writer with a deep understanding of human psychology, influence, and persuasion. Your task is to transform a candidate's resume to better align with a given job description, using an intensity scale from 0 to 5:

Intensity 0: Make no changes to the resume (copy it verbatim).
Intensity 5: Make comprehensive changes so the candidate's experience perfectly aligns with the job requirements, while maintaining credibility.
When rewriting, focus on:

Relevance: Incorporate role-specific keywords, industry language, and highlight relevant or transferable skills.
ATS Optimization: Use terminology from the job description, reorder and/or add skills, and adjust bullet points for clarity.
Persuasion & Influence: Showcase achievements (preferably with measurable impacts), align soft/hard skills with the role, and illustrate how the candidate's background meets the job needs.
Resume Structure: Return only the new resume text in the sections listed below. Do not include any extra explanations, disclaimers, or commentary.

Sections & Formatting

CONTACT INFORMATION:
Name, Email, Phone, Location

PROFESSIONAL SUMMARY:
A concise sentence summarizing the candidate's relevant experience, skills, and career highlights (tailored to the job description).

EXPERIENCE (make sure to follow this format):
Company Name, Title, Dates
Under each position, use bullet points (•) to highlight responsibilities, achievements, and any quantifiable impact—aligned with the job requirements.

EDUCATION:
School, Degree, Graduation Date (if relevant).

SKILLS:
Ordered by relevance to the job description.

Important Details
Ignore any content that is too personal or unrelated to the job description.
Maintain credibility: do not invent experience or achievements that couldn't logically be inferred from the resume.
If the candidate is transitioning to a new industry, highlight transferable skills and accomplishments that demonstrate potential success in the target role.
Rewrite bullet points for clarity and impact, using active verbs and measurable achievements where possible.
Return only the new resume. Do not include any other text.
    
    Here is the job description: {job_description}, here's the resume: {resume_text}, and here is the intensity: 2. 

     """
    
     response = client.chat.completions.create(
         model="gpt-4o-mini",
         messages=[
             {"role": "system", "content": "You are an expert in tailoring resumes."},
             {"role": "user", "content": prompt}
         ],
         max_tokens=1000  # Adjust based on your needs
     )
    
    # # Extract the response content
     tailored_resume = response.choices[0].message.content
     return tailored_resume

def save_resume_to_docx(resume_text):
    """Save resume to DOCX with proper formatting"""
    doc = Document()
    styles = create_resume_styles(doc)
    
    # Set margins
    sections = doc.sections
    for section in sections:
        section.top_margin = Inches(1)
        section.bottom_margin = Inches(1)
        section.left_margin = Inches(1)
        section.right_margin = Inches(1)

    # Split content into sections
    sections = resume_text.split('\n\n')
    
    for section in sections:
        if not section.strip():
            continue
            
        lines = section.strip().split('\n')
        section_title = lines[0].strip()
        
        # Handle Contact Information section
        if "CONTACT INFORMATION" in section_title:
            p = doc.add_paragraph(style=styles['section'])
            p.add_run(section_title)
            for line in lines[1:]:
                if line.strip():
                    p = doc.add_paragraph(style=styles['contact'])
                    p.add_run(line.strip())
            continue

        # Handle other sections
        p = doc.add_paragraph(style=styles['section'])
        p.add_run(section_title)
        
        # Add content under each section
        for line in lines[1:]:
            if not line.strip():
                continue
                
            p = doc.add_paragraph(style=styles['normal'])
            if line.strip().startswith('•'):
                p.style = 'List Bullet'
                p.add_run(line.strip()[1:].strip())
            else:
                # Check if this is a job title/company line
                if ' - ' in line or '|' in line:
                    p.add_run(line.strip()).bold = True
                else:
                    p.add_run(line.strip())

    return doc

def create_resume_styles(doc):
    """Create consistent styles for the resume document"""
    # Create section styles
    styles = doc.styles

    # Header style (for name and section headers)
    header_style = doc.styles.add_style('HeaderStyle', WD_STYLE_TYPE.PARAGRAPH)
    header_style.font.name = 'Calibri'
    header_style.font.size = Pt(14)
    header_style.paragraph_format.space_after = Pt(12)

    # Section header style
    section_style = doc.styles.add_style('SectionStyle', WD_STYLE_TYPE.PARAGRAPH)
    section_style.font.name = 'Calibri'
    section_style.font.size = Pt(14)
    section_style.font.bold = True
    section_style.paragraph_format.space_after = Pt(12)

    # Normal text style
    normal_style = styles['Normal']
    normal_style.font.name = 'Calibri'
    normal_style.font.size = Pt(11)
    normal_style.paragraph_format.space_after = Pt(6)
    normal_style.paragraph_format.line_spacing = 1.15

    # Contact info style
    contact_style = doc.styles.add_style('ContactStyle', WD_STYLE_TYPE.PARAGRAPH)
    contact_style.font.name = 'Calibri'
    contact_style.font.size = Pt(11)
    contact_style.paragraph_format.space_after = Pt(24)
    contact_style.paragraph_format.alignment = WD_ALIGN_PARAGRAPH.LEFT

    return {
        'header': header_style,
        'section': section_style,
        'normal': normal_style,
        'contact': contact_style
    }


def docx_to_txt(docx_path, txt_path):
    """
    Reads a .docx file and writes its content to a .txt file.
    
    Parameters:
    - docx_path: Path to the input .docx file.
    - txt_path: Path to the output .txt file.
    """
    # Load the .docx document
    document = Document(docx_path)
    
    # Extract all text from the document
    text = []
    for paragraph in document.paragraphs:
        text.append(paragraph.text)
    
    # Write the text to the .txt file
    with open(txt_path, 'w', encoding='utf-8') as f:
        f.write("\n".join(text))
    logger.info("Converted %s to %s", docx_path, txt_path)

def process_resume_and_job_description(resume_path: str, job_description_path: str, output_path: str):
    """Process resume and job description files"""
    with open(resume_path, 'r', encoding='utf-8') as f:
        resume_text = f.read()
    
    with open(job_description_path, 'r', encoding='utf-8') as f:
        job_description = f.read()

    tailored_resume = customize_resume(resume_text, job_description)
    save_resume_to_docx(tailored_resume, output_path)
    logger.info("Customized resume saved to %s", output_path)
