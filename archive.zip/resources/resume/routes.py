from flask import Blueprint
from .resource import ResumeUpload, ResumeProcessor, ResumeDocxGenerator

# Create a Blueprint for resume-related routes
resume_bp = Blueprint('resume_routes', __name__, url_prefix='/api')

# Route for uploading resumes
@resume_bp.route('/upload_resume', methods=['POST'])
def upload_resume():
    return ResumeUpload.upload_resume()

# Route for processing and tailoring resumes
@resume_bp.route('/tailor_resume', methods=['POST'])
def process_resume():
    return ResumeProcessor.process_resume()

# Route for generating DOCX files
@resume_bp.route('/generate_docx', methods=['POST'])
def generate_docx():
    return ResumeDocxGenerator.generate_docx()
