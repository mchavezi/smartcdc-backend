# models.py
import uuid
import enum
from flask_jwt_extended import create_access_token
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime, timedelta
import secrets
from sqlalchemy.dialects.mysql import CHAR
from sqlalchemy import Enum, JSON

db = SQLAlchemy()

from resources.postgres_database.models import PostgresDatabase
from resources.postgres_replication_slot.models import PostgresReplicationSlot, ReplicationSlotStatus
from resources.wal_events.models import WalEvent

class User(db.Model):
    __tablename__ = 'users'

    id = db.Column(CHAR(36), primary_key=True, default=lambda: str(uuid.uuid4()), unique=True, nullable=False)
    name = db.Column(db.String(100))
    last_name = db.Column(db.String(50))
    email = db.Column(db.String(120), unique=True, nullable=False)
    password = db.Column(db.String(200), nullable=False)
    location = db.Column(db.String(100))
    job_title = db.Column(db.String(100))
    resume = db.Column(db.String(500))
    avi = db.Column(db.String(500))
    is_verified = db.Column(db.Boolean, default=False)
    verification_token = db.Column(db.String(100), unique=True)
    token_expiry = db.Column(db.DateTime)
    resume_tokens = db.Column(db.Integer, default=1)  # Start with 1 free credit
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    def has_available_credits(self):
        return self.resume_tokens > 0

    def use_credit(self):
        if self.resume_tokens > 0:
            self.resume_tokens -= 1
            return True
        return False

    def add_credits(self, amount):
        self.resume_tokens += amount

    __table_args__ = (
        db.UniqueConstraint('verification_token', name='uq_verification_token'),
    )

    def get_access_token(self):
        # You can pass additional claims or data to the JWT if necessary
        self.access_token = create_access_token(identity=self.id)
        self.token_expiry = datetime.utcnow() + timedelta(hours=24)
        return self.access_token

    def generate_verification_token(self):
        """Generate a unique verification token."""
        self.verification_token = secrets.token_urlsafe(32)
        self.token_expiry = datetime.utcnow() + timedelta(hours=24)  # Token expires in 24 hours
        return self.verification_token

    def verify_email(self):
        """Mark the user's email as verified."""
        self.is_verified = True
        self.verification_token = None
        self.token_expiry = None

    def check_verification_token(self, token):
        """Check if the given token is valid and not expired."""
        if not self.verification_token or not self.token_expiry:
            return False
        if self.verification_token != token:
            return False
        if datetime.utcnow() > self.token_expiry:
            return False
        return True
        
