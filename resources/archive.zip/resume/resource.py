from flask import jsonify, request, current_app, send_file
from flask_jwt_extended import jwt_required, get_jwt_identity
from werkzeug.utils import secure_filename
from models import User, db
from services.tailor_service import customize_resume, save_resume_to_docx
import os
import io
from datetime import datetime
from docx import Document

class ResumeUpload:
    @staticmethod
    @jwt_required()
    def upload_resume():
        resume_file = request.files.get('resume')
        if not resume_file:
            return jsonify({'message': 'No file uploaded'}), 400
        
        filename = secure_filename(resume_file.filename)
        user_id = get_jwt_identity()
        user_folder = os.path.join('uploads', str(user_id))
        os.makedirs(user_folder, exist_ok=True)
        file_path = os.path.join(user_folder, filename)
        resume_file.save(file_path)
        
        return jsonify({'message': 'Resume uploaded successfully'}), 201

class ResumeProcessor:
    @staticmethod
    @jwt_required()
    def process_resume():
        try:
            user_id = get_jwt_identity()
            user = User.query.get(user_id)

            if not user:
                return jsonify({'error': 'User not found'}), 404

            data = request.get_json()
            if not data:
                return jsonify({'error': 'No data provided'}), 400

            # Handle HTML content from editor
            if data.get('is_html'):
                html_content = data.get('content_html')
                if not html_content:
                    return jsonify({'error': 'No content provided'}), 400

                # If client wants DOCX
                if request.headers.get('Accept') == 'application/octet-stream':
                    doc = Document()
                    doc.add_paragraph(html_content)  # Simplified for demonstration
                    docx_stream = io.BytesIO()
                    doc.save(docx_stream)
                    docx_stream.seek(0)
                    
                    filename = f'Customized_Resume_{datetime.now().strftime("%Y-%m-%d")}.docx'
                    return send_file(docx_stream, as_attachment=True, download_name=filename)

                return jsonify({'preview': html_content})

            # Handle resume generation
            resume_text = data.get('resume_text', '').strip()
            jd_text = data.get('jd_text', '').strip()
            
            if not resume_text or not jd_text:
                return jsonify({'error': 'Both resume and job description are required'}), 400

            if user.resume_tokens < 1:
                return jsonify({
                    'error': 'Insufficient credits',
                    'message': 'Please purchase more credits to generate resumes'
                }), 403

            tailored_resume_text = customize_resume(resume_text, jd_text)

            # If client wants DOCX
            if request.headers.get('Accept') == 'application/octet-stream':
                doc = save_resume_to_docx(tailored_resume_text)
                docx_stream = io.BytesIO()
                doc.save(docx_stream)
                docx_stream.seek(0)
                
                filename = f'Customized_Resume_{datetime.now().strftime("%Y-%m-%d")}.docx'
                user.resume_tokens -= 1
                db.session.commit()
                return send_file(docx_stream, as_attachment=True, download_name=filename)

            # Return preview text
            return jsonify({'preview': tailored_resume_text})
        except Exception as e:
            return jsonify({'error': str(e)}), 500

class ResumeDocxGenerator:
    @staticmethod
    @jwt_required()
    def generate_docx():
        try:
            data = request.get_json()
            if not data or 'content' not in data:
                return jsonify({'error': 'No content provided'}), 400

            content = data['content']
            doc = Document()
            
            # Add content to document with proper paragraph breaks
            for paragraph in content.split('\n\n'):
                if paragraph.strip():
                    p = doc.add_paragraph()
                    p.add_run(paragraph.strip())

            # Convert to bytes and return
            docx_stream = io.BytesIO()
            doc.save(docx_stream)
            docx_stream.seek(0)
            
            return send_file(
                docx_stream,
                mimetype='application/vnd.openxmlformats-officedocument.wordprocessingml.document',
                as_attachment=True,
                download_name=f'Customized_Resume_{datetime.now().strftime("%Y-%m-%d")}.docx'
            )

        except Exception as e:
            logger.error(f"Error generating DOCX: {str(e)}")
            return jsonify({'error': 'Failed to generate document'}), 500
